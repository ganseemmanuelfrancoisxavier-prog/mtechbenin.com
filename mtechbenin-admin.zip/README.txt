MTECHBENIN — ADMIN
====================

1. Dans ton dépôt GitHub, crée un dossier nommé:
   admin

2. Mets index.html dans ce dossier:
   admin/index.html

3. Ton administration sera accessible avec:
   https://ganseemmanuelfrancoisxavier-prog.github.io/mtechbenin.com/admin/

4. Démo actuelle:
   Email: admin@mtechbenin.com
   Mot de passe: MTECH2026

IMPORTANT:
Cette connexion est uniquement une maquette de démonstration.
Le mot de passe est visible dans le JavaScript et ne doit PAS être utilisé
pour une vraie boutique en production.

La prochaine étape est de connecter l'administration à une vraie base de
données + authentification serveur, puis de relier produits, commandes,
paiements, clients et WhatsApp.
